# Dental Logic - Ecosistema de Software Dental 🦷💻

Proyecto de portafolio profesional desarrollado por **Nataly Santana**. 
Este sitio web es una vitrina de soluciones tecnológicas diseñadas específicamente para optimizar flujos de trabajo en laboratorios dentales, fusionando la precisión clínica con el desarrollo en **Python**.

## 🚀 Tecnologías Utilizadas
* **Frontend:** HTML5, CSS3 (Custom), JavaScript (Vanilla).
* **Framework:** Bootstrap 5.3 (Diseño Responsive).
* **Lógica de Negocio:** Integración dinámica con WhatsApp API.
* **Despliegue:** GitHub Pages.

## 🛠️ Estructura del Proyecto
* `index.html`: Estructura semántica del sitio.
* `css/style.css`: Estilos personalizados (Medical Modern UI).
* `js/script.js`: Lógica del carrito de compras y gestión de pedidos.

## 🔗 Enlaces
* **Repositorio Público:** [https://github.com/tu-usuario/nombre-del-repo](https://github.com/tu-usuario/nombre-del-repo)
* **Demo en Vivo:** [https://natalysantana.github.io/](https://natalysantana.github.io/)

---
*Desarrollado en Valdivia, Chile - 2026*
